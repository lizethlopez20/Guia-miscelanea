def sumar_numeros():
    """Suma todos los números ingresados por teclado hasta que se ingrese cero."""
    suma = 0
    while True:
        try:
            num = float(input("Ingrese un número (ingrese 0 para terminar): "))
            if num == 0:
                break
            suma += num
        except ValueError:
            print("Error: Por favor, ingrese un número válido.")
    return suma

def main():
    """Función principal del programa."""
    total = sumar_numeros()
    print("La suma de todos los números ingresados es:", total)

if __name__ == "__main__":
    main()
