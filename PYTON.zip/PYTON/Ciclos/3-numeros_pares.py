def imprimir_pares():
    """Imprime los números pares entre 1 y 100."""
    print("Los números pares entre 1 y 100 son:")
    for i in range(2, 101, 2):
        print(i)

def main():
    """Función principal del programa."""
    imprimir_pares()

if __name__ == "__main__":
    main()
