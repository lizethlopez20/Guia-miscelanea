def numeros_entre_naturales_ascendente(num1, num2):
    """Genera y muestra todos los números naturales entre num1 y num2 en secuencia ascendente."""
    print("Números comprendidos entre", num1, "y", num2, "en secuencia ascendente:")
    for i in range(num1, num2 + 1):
        print(i, end=" ")

def main():
    """Función principal del programa."""
    try:
        num1 = int(input("Ingrese el primer número natural: "))
        num2 = int(input("Ingrese el segundo número natural (mayor que el primero): "))
        
        if num1 < 0 or num2 < 0:
            print("Error: Por favor, ingrese números naturales válidos.")
        elif num1 >= num2:
            print("Error: El primer número debe ser menor que el segundo.")
        else:
            numeros_entre_naturales_ascendente(num1, num2)
    except ValueError:
        print("Error: Por favor, ingrese números naturales válidos.")

if __name__ == "__main__":
    main()
