def imprimir_multiplos_de_tres():
    """Imprime todos los múltiplos de 3 en el rango de 1 a 100."""
    print("Los múltiplos de 3 entre 1 y 100 son:")
    for i in range(1, 101):
        if i % 3 == 0:
            print(i)

def main():
    """Función principal del programa."""
    imprimir_multiplos_de_tres()

if __name__ == "__main__":
    main()
