def imprimir_impares():
    """Imprime los números impares entre 0 y 100."""
    print("Los números impares entre 0 y 100 son:")
    for i in range(1, 101, 2):
        print(i)

def main():
    """Función principal del programa."""
    imprimir_impares()

if __name__ == "__main__":
    main()
