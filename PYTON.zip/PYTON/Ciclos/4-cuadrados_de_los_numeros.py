def imprimir_cuadrados_del_1_al_30():
    """Imprime los cuadrados de los números del 1 al 30."""
    print("Los cuadrados de los números del 1 al 30 son:")
    for i in range(1, 31):
        cuadrado = i ** 2
        print("El cuadrado de", i, "es", cuadrado)

def main():
    """Función principal del programa."""
    imprimir_cuadrados_del_1_al_30()

if __name__ == "__main__":
    main()
