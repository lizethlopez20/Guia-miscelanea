def sumar_cuadrados_cien_primeros_naturales():
    """Calcula la suma de los cuadrados de los cien primeros números naturales."""
    suma_cuadrados = 0
    for i in range(1, 101):
        suma_cuadrados += i ** 2
    return suma_cuadrados

def main():
    """Función principal del programa."""
    resultado = sumar_cuadrados_cien_primeros_naturales()
    print("La suma de los cuadrados de los cien primeros números naturales es:", resultado)

if __name__ == "__main__":
    main()
