import math

def calcular_area_triangulo(base, altura):
    """Calcula el área de un triángulo dado su base y altura."""
    return (base * altura) / 2

def menu():
    """Muestra el menú de opciones."""
    print("=== MENÚ ===")
    print("1. Calcular área de un triángulo")
    print("99. Salir")

def main():
    """Función principal del programa."""
    while True:
        menu()
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            # Solicitar la base y la altura al usuario
            base = float(input("Ingrese la longitud de la base del triángulo: "))
            altura = float(input("Ingrese la altura del triángulo: "))
            
            # Calcular el área del triángulo
            area = calcular_area_triangulo(base, altura)
            print("El área del triángulo es:", area)
        elif opcion == "99":
            print("¡Hasta luego!")
            break
        else:
            print("Opción no válida. Por favor, seleccione una opción válida.")

if __name__ == "__main__":
    main()
