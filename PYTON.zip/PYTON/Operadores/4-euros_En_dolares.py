def euros_a_dolares():
    """Convierte una cantidad de euros a dólares."""
    try:
        euros = float(input("Ingrese la cantidad en euros: "))
        tasa_cambio = 1.13  # Tasa de cambio actual de euros a dólares
        dolares = euros * tasa_cambio
        print("La cantidad en dólares es:", dolares)
    except ValueError:
        print("Error: Por favor, ingrese una cantidad válida en euros.")

def main():
    """Función principal del programa."""
    euros_a_dolares()

if __name__ == "__main__":
    main()
