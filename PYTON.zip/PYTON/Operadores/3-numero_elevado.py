def elevar_al_cuadrado():
    """Ingresa un número por teclado y muestra el número elevado al cuadrado."""
    try:
        numero = float(input("Ingrese un número: "))
        resultado = numero ** 2
        print("El número elevado al cuadrado es:", resultado)
    except ValueError:
        print("Error: Por favor, ingrese un número válido.")

def main():
    """Función principal del programa."""
    elevar_al_cuadrado()

if __name__ == "__main__":
    main()
5