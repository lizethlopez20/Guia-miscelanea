def calcular_area_perimetro_cuadrado():
    """Calcula el área y el perímetro de un cuadrado."""
    try:
        lado = float(input("Ingrese la longitud del lado del cuadrado: "))
        
        # Calcular el área y el perímetro
        area = lado ** 2
        perimetro = lado * 4
        
        print("El área del cuadrado es:", area)
        print("El perímetro del cuadrado es:", perimetro)
    except ValueError:
        print("Error: Por favor, ingrese una longitud de lado válida.")

def main():
    """Función principal del programa."""
    calcular_area_perimetro_cuadrado()

if __name__ == "__main__":
    main()
