import math

def calcular_longitud_area_circunferencia(radio):
    """Calcula la longitud de una circunferencia y el área de un círculo inscrito."""
    longitud = 2 * math.pi * radio
    area_inscrita = math.pi * (radio ** 2)
    return longitud, area_inscrita

def main():
    """Función principal del programa."""
    try:
        radio = float(input("Ingrese el radio de la circunferencia: "))
        
        longitud, area_inscrita = calcular_longitud_area_circunferencia(radio)
        print("La longitud de la circunferencia es:", longitud)
        print("El área del círculo inscrito es:", area_inscrita)
    except ValueError:
        print("Error: Por favor, ingrese un valor numérico válido para el radio.")

if __name__ == "__main__":
    main()
