import math

def calcular_area_volumen_cilindro(radio, altura):
    """Calcula el área y el volumen de un cilindro."""
    area_base = math.pi * (radio ** 2)
    area_lateral = 2 * math.pi * radio * altura
    area_total = 2 * area_base + area_lateral
    volumen = area_base * altura
    return area_total, volumen

def main():
    """Función principal del programa."""
    try:
        radio = float(input("Ingrese el radio del cilindro: "))
        altura = float(input("Ingrese la altura del cilindro: "))
        
        area, volumen = calcular_area_volumen_cilindro(radio, altura)
        print("El área total del cilindro es:", area)
        print("El volumen del cilindro es:", volumen)
    except ValueError:
        print("Error: Por favor, ingrese valores numéricos válidos para el radio y la altura.")

if __name__ == "__main__":
    main()
