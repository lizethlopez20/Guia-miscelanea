def sumar_numeros():
    """Ingresa dos números por teclado y muestra la suma."""
    try:
        num1 = float(input("Ingrese el primer número: "))
        num2 = float(input("Ingrese el segundo número: "))
        
        suma = num1 + num2
        print("La suma de los números es:", suma)
    except ValueError:
        print("Error: Por favor, ingrese números válidos.")

def main():
    """Función principal del programa."""
    sumar_numeros()

if __name__ == "__main__":
    main()
