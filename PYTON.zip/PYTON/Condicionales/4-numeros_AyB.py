def suma_o_resta(A, B):
    """Suma A y B si A es menor que B, sino resta B de A."""
    if A < B:
        resultado = A + B
    else:
        resultado = A - B
    return resultado

def main():
    """Función principal del programa."""
    try:
        A = float(input("Ingrese el primer número (A): "))
        B = float(input("Ingrese el segundo número (B): "))
        
        resultado = suma_o_resta(A, B)
        print("El resultado de la operación es:", resultado)
    except ValueError:
        print("Error: Por favor, ingrese números válidos.")

if __name__ == "__main__":
    main()
