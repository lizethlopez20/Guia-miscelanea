def calcular_promedio(num1, num2, num3):
    """Calcula el promedio de tres números."""
    return (num1 + num2 + num3) / 3

def main():
    """Función principal del programa."""
    try:
        num1 = float(input("Ingrese el primer número: "))
        num2 = float(input("Ingrese el segundo número: "))
        num3 = float(input("Ingrese el tercer número: "))
        
        promedio = calcular_promedio(num1, num2, num3)
        print("El promedio de los tres números es:", promedio)
    except ValueError:
        print("Error: Por favor, ingrese valores numéricos válidos.")

if __name__ == "__main__":
    main()
