def es_bisiesto(year):
    """Determina si un año es bisiesto o no."""
    if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
        return True
    else:
        return False

def main():
    """Función principal del programa."""
    try:
        year = int(input("Ingrese un año: "))
        
        if es_bisiesto(year):
            print("El año", year, "es bisiesto.")
        else:
            print("El año", year, "no es bisiesto.")
    except ValueError:
        print("Error: Por favor, ingrese un año válido.")

if __name__ == "__main__":
    main()
