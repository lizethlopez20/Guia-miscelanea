def calcular_cociente(A, B):
    """Calcula el cociente entre A y B, manejando el caso de división por cero."""
    if B == 0:
        return "La división no es posible, el divisor (B) es cero."
    else:
        return A / B

def main():
    """Función principal del programa."""
    try:
        A = float(input("Ingrese el primer número (A): "))
        B = float(input("Ingrese el segundo número (B): "))
        
        resultado = calcular_cociente(A, B)
        print("El cociente entre A y B es:", resultado)
    except ValueError:
        print("Error: Por favor, ingrese números válidos.")

if __name__ == "__main__":
    main()
