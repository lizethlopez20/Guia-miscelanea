def encontrar_mayor_menor(num1, num2):
    """Encuentra el mayor y el menor de dos números."""
    if num1 > num2:
        mayor = num1
        menor = num2
    else:
        mayor = num2
        menor = num1
    return mayor, menor

def main():
    """Función principal del programa."""
    try:
        num1 = float(input("Ingrese el primer número: "))
        num2 = float(input("Ingrese el segundo número: "))
        
        mayor, menor = encontrar_mayor_menor(num1, num2)
        print("El mayor número es:", mayor)
        print("El menor número es:", menor)
    except ValueError:
        print("Error: Por favor, ingrese números válidos.")

if __name__ == "__main__":
    main()
