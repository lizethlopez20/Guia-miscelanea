def encontrar_menor_mayor(num1, num2, num3):
    """Encuentra el menor y el mayor de tres números."""
    menor = min(num1, num2, num3)
    mayor = max(num1, num2, num3)
    return menor, mayor

def main():
    """Función principal del programa."""
    try:
        num1 = int(input("Ingrese el primer número entero positivo: "))
        num2 = int(input("Ingrese el segundo número entero positivo: "))
        num3 = int(input("Ingrese el tercer número entero positivo: "))
        
        if num1 <= 0 or num2 <= 0 or num3 <= 0:
            print("Error: Por favor, ingrese números enteros positivos.")
            return
        
        menor, mayor = encontrar_menor_mayor(num1, num2, num3)
        print("El menor número es:", menor)
        print("El mayor número es:", mayor)
    except ValueError:
        print("Error: Por favor, ingrese números enteros válidos.")

if __name__ == "__main__":
    main()
